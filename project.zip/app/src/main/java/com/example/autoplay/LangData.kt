package com.example.autoplay

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Языковые данные Tesseract для кириллицы (скачиваются один раз). */
object LangData {
    private val langs = listOf("rus", "eng")
    private const val MIN_SIZE = 100_000L

    fun baseDir(ctx: Context) = File(ctx.filesDir, "tesseract")
    private fun tessDir(ctx: Context) = File(baseDir(ctx), "tessdata")

    fun ready(ctx: Context): Boolean = langs.all {
        val f = File(tessDir(ctx), "$it.traineddata")
        f.exists() && f.length() > MIN_SIZE
    }

    /** Блокирующее скачивание. Возвращает текст ошибки или null, если всё хорошо. */
    fun downloadAll(ctx: Context): String? {
        return try {
            tessDir(ctx).mkdirs()
            for (lang in langs) {
                val target = File(tessDir(ctx), "$lang.traineddata")
                if (target.exists() && target.length() > MIN_SIZE) continue
                val tmp = File(tessDir(ctx), "$lang.traineddata.part")
                val url = URL("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.inputStream.use { input ->
                    tmp.outputStream().use { out -> input.copyTo(out) }
                }
                conn.disconnect()
                if (tmp.length() < MIN_SIZE || !tmp.renameTo(target)) {
                    tmp.delete()
                    return "bad file ($lang)"
                }
            }
            null
        } catch (e: Exception) {
            e.message ?: "error"
        }
    }
}
