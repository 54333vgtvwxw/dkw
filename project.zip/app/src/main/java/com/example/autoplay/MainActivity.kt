package com.example.autoplay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private lateinit var wordsBox: LinearLayout
    private lateinit var exactBox: LinearLayout
    private lateinit var minField: EditText
    private lateinit var secField: EditText
    private lateinit var dirSpinner: Spinner
    private lateinit var dirDesc: TextView
    private lateinit var leftF: EditText
    private lateinit var topF: EditText
    private lateinit var rightF: EditText
    private lateinit var bottomF: EditText
    private lateinit var tapAllBox: Switch
    private lateinit var cyrStatus: TextView
    private var downloading = false

    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private var cField = 0
    private val cAccent = 0xFF6C5CE7.toInt()

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val dirNames = intArrayOf(R.string.dir_0, R.string.dir_1, R.string.dir_2, R.string.dir_3, R.string.dir_4)
    private val dirDescs = intArrayOf(R.string.dir_d0, R.string.dir_d1, R.string.dir_d2, R.string.dir_d3, R.string.dir_d4)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { save() }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    private fun currentLang(): String = resources.configuration.locales[0].language

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        cBg = if (dark) 0xFF121214.toInt() else 0xFFF2F3F7.toInt()
        cCard = if (dark) 0xFF1E1E24.toInt() else 0xFFFFFFFF.toInt()
        cText = if (dark) 0xFFEEEEF2.toInt() else 0xFF1B1B1F.toInt()
        cSub = if (dark) 0xFF9A9AA6.toInt() else 0xFF6B6B76.toInt()
        cField = if (dark) 0xFF2B2B34.toInt() else 0xFFEDEDF3.toInt()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }

        // ---- Шапка с иконкой ----
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(14))
        }
        head.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) },
            LinearLayout.LayoutParams(dp(56), dp(56)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titles.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
        })
        titles.addView(TextView(this).apply {
            text = getString(R.string.subtitle)
            textSize = 13f
            setTextColor(cSub)
        })
        head.addView(titles)
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val ru = currentLang() == "ru"
        head.addView(TextView(this).apply {
            text = "🌐 " + if (ru) "RU" else "EN"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
            background = rounded(cField, 20)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                save()
                Prefs.saveLanguage(this@MainActivity, if (ru) "en" else "ru")
                recreate()
            }
        })
        root.addView(head)

        status = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        root.addView(status, LinearLayout.LayoutParams(WRAP, WRAP))

        // ---- Слова (как часть текста) ----
        card(getString(R.string.words_title), getString(R.string.words_hint)) {
            wordsBox = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            addView(wordsBox)
            Prefs.words(this@MainActivity).forEach { addRow(wordsBox, it) }
            addView(button(getString(R.string.add_word), false) {
                addRow(wordsBox, "")
                focusLast(wordsBox)
            }, lp(10))
        }

        // ---- Точные слова ----
        card(getString(R.string.exact_title), getString(R.string.exact_hint)) {
            exactBox = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            addView(exactBox)
            Prefs.exactWords(this@MainActivity).forEach { addRow(exactBox, it) }
            addView(button(getString(R.string.add_word), false) {
                addRow(exactBox, "")
                focusLast(exactBox)
            }, lp(10))
        }

        // ---- Интервал ----
        card(getString(R.string.interval_title)) {
            val total = Prefs.intervalSec(this@MainActivity)
            minField = numberField((total / 60).toString())
            secField = numberField((total % 60).toString())
            addView(inline(minField, labelText(getString(R.string.min_label)), secField,
                labelText(getString(R.string.sec_label))), lp(10))
            addView(sub(getString(R.string.interval_hint)))
        }

        // ---- Выбор кнопки ----
        card(getString(R.string.select_title), getString(R.string.select_hint)) {
            dirSpinner = Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(
                    this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                    dirNames.map { getString(it) }
                )
                setSelection(Prefs.direction(this@MainActivity))
                background = rounded(cField, 10)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            addView(dirSpinner, lp(10))
            dirDesc = sub(getString(dirDescs[Prefs.direction(this@MainActivity).coerceIn(0, 4)]))
            addView(dirDesc)

            tapAllBox = Switch(this@MainActivity).apply {
                text = getString(R.string.tap_all)
                setTextColor(cText)
                isChecked = Prefs.tapAll(this@MainActivity)
                setPadding(0, dp(16), 0, dp(4))
            }
            addView(tapAllBox)
            addView(sub(getString(R.string.tap_all_desc)))

            addView(TextView(this@MainActivity).apply {
                text = getString(R.string.area_title)
                setTextColor(cText)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(16), 0, dp(4))
            })
            val reg = Prefs.region(this@MainActivity)
            leftF = numberField(reg[0].toString())
            topF = numberField(reg[1].toString())
            rightF = numberField(reg[2].toString())
            bottomF = numberField(reg[3].toString())
            addView(inline(labelText(getString(R.string.area_left)), leftF, labelText(" %      "),
                labelText(getString(R.string.area_top)), topF, labelText(" %")), lp(6))
            addView(inline(labelText(getString(R.string.area_right)), rightF, labelText(" %      "),
                labelText(getString(R.string.area_bottom)), bottomF, labelText(" %")), lp(8))
            addView(sub(getString(R.string.area_desc)))
        }

        // ---- Кириллица ----
        card(getString(R.string.cyr_title), getString(R.string.cyr_hint)) {
            cyrStatus = sub("")
            cyrStatus.setTextColor(cText)
            addView(cyrStatus, lp(8))
            addView(button(getString(R.string.cyr_download), false) { startDownload() }, lp(8))
        }
        refreshCyr(null)

        // ---- Плавающие кнопки ----
        card(getString(R.string.panel_title), getString(R.string.panel_hint)) {
            addView(Switch(this@MainActivity).apply {
                text = getString(R.string.panel_switch)
                setTextColor(cText)
                isChecked = Prefs.showPanel(this@MainActivity)
                setPadding(0, dp(12), 0, dp(4))
                setOnCheckedChangeListener { _, c -> Prefs.saveShowPanel(this@MainActivity, c) }
            })
        }

        // ---- Настройка ----
        card(getString(R.string.setup_title), getString(R.string.setup_hint)) {
            addView(button(getString(R.string.step_restricted), false) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }, lp(10))
            addView(button(getString(R.string.step_enable), true) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, lp(8))
            addView(button(getString(R.string.step_battery), false) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }, lp(8))
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.footer)
            textSize = 12f
            setTextColor(cSub)
            setPadding(dp(4), dp(16), dp(4), 0)
        })

        // слушатели ставим после создания всех полей
        minField.addTextChangedListener(watcher)
        secField.addTextChangedListener(watcher)
        for (f in listOf(leftF, topF, rightF, bottomF)) f.addTextChangedListener(watcher)
        tapAllBox.setOnCheckedChangeListener { _, _ -> save() }
        dirSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                dirDesc.text = getString(dirDescs[pos.coerceIn(0, 4)])
                save()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            addView(root)
        })
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (!downloading) refreshCyr(null)
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    // ---------- оформление ----------

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun lp(topDp: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(topDp) }

    private fun card(title: String, hint: String? = null, build: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cCard, 16)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
        })
        if (hint != null) c.addView(sub(hint))
        c.build()
        root.addView(c, lp(12))
    }

    private fun sub(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(cSub)
        setPadding(0, dp(4), 0, 0)
    }

    private fun labelText(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(cText)
    }

    private fun inline(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        views.forEach { addView(it) }
    }

    private fun styleField(e: EditText) {
        e.setTextColor(cText)
        e.setHintTextColor(cSub)
        e.background = rounded(cField, 10)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun numberField(value: String) = EditText(this).apply {
        setText(value)
        inputType = InputType.TYPE_CLASS_NUMBER
        gravity = Gravity.CENTER
        minWidth = dp(70)
        styleField(this)
    }

    private fun button(title: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        textSize = 15f
        setTextColor(if (filled) Color.WHITE else cAccent)
        background = if (filled) rounded(cAccent, 12) else rounded(Color.TRANSPARENT, 12, cAccent)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    // ---------- строки со словами ----------

    private fun addRow(box: LinearLayout, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val field = EditText(this).apply {
            setText(value)
            hint = getString(R.string.word_hint)
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            styleField(this)
        }
        field.addTextChangedListener(watcher)
        row.addView(field, LinearLayout.LayoutParams(0, WRAP, 1f))

        val trash = TextView(this).apply {
            text = "✕"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(cSub)
            setOnClickListener {
                box.removeView(row)
                save()
            }
        }
        row.addView(trash, LinearLayout.LayoutParams(dp(48), dp(48)))
        box.addView(row, lp(8))
    }

    private fun focusLast(box: LinearLayout) {
        (box.getChildAt(box.childCount - 1) as LinearLayout).getChildAt(0).requestFocus()
    }

    private fun readWords(box: LinearLayout) = (0 until box.childCount).mapNotNull { i ->
        val row = box.getChildAt(i) as LinearLayout
        (row.getChildAt(0) as EditText).text.toString().trim().ifEmpty { null }
    }

    // ---------- сохранение и статус ----------

    private fun save() {
        if (!::wordsBox.isInitialized || !::exactBox.isInitialized ||
            !::minField.isInitialized || !::secField.isInitialized ||
            !::dirSpinner.isInitialized || !::leftF.isInitialized || !::topF.isInitialized ||
            !::rightF.isInitialized || !::bottomF.isInitialized || !::tapAllBox.isInitialized
        ) return

        Prefs.saveWords(this, readWords(wordsBox))
        Prefs.saveExactWords(this, readWords(exactBox))

        val m = minField.text.toString().toIntOrNull() ?: 0
        val s = secField.text.toString().toIntOrNull() ?: 0
        Prefs.saveInterval(this, (m * 60 + s).coerceAtLeast(1))

        Prefs.saveDirection(this, dirSpinner.selectedItemPosition)
        Prefs.saveTapAll(this, tapAllBox.isChecked)
        fun pct(f: EditText, d: Int) = (f.text.toString().toIntOrNull() ?: d).coerceIn(0, 100)
        Prefs.saveRegion(this, pct(leftF, 0), pct(topF, 0), pct(rightF, 100), pct(bottomF, 100))
    }

    private fun startDownload() {
        if (downloading) return
        downloading = true
        cyrStatus.text = getString(R.string.cyr_downloading)
        val appCtx = applicationContext
        Thread {
            val err = LangData.downloadAll(appCtx)
            runOnUiThread {
                downloading = false
                refreshCyr(err)
            }
        }.start()
    }

    private fun refreshCyr(err: String?) {
        cyrStatus.text = when {
            err != null -> getString(R.string.cyr_failed, err)
            LangData.ready(this) -> getString(R.string.cyr_ready)
            else -> getString(R.string.cyr_missing)
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun refreshStatus() {
        val on = isServiceEnabled()
        status.text = getString(if (on) R.string.status_on else R.string.status_off)
        status.background = rounded(if (on) 0xFF2E9E5B.toInt() else 0xFFD64545.toInt(), 20)
    }
}
