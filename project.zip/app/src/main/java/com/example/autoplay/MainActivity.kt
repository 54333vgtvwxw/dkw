package com.example.autoplay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Fortnite AutoPlay"
            textSize = 24f
        })

        status = TextView(this).apply {
            textSize = 18f
            setPadding(0, 32, 0, 32)
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "Пройдите шаги по порядку. Fortnite должен быть на английском языке. " +
                "Сервис сам нажимает PLAY AGAIN на экране итогов матча."
            textSize = 14f
            setPadding(0, 0, 0, 32)
        })

        addButton("1. Разрешить уведомления") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            } else {
                openNotificationSettings()
            }
        }
        addButton("1б. Настройки уведомлений приложения") { openNotificationSettings() }
        addButton("2. Сведения о приложении\n(⋮ → Разрешить ограниченные настройки)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
        addButton("3. Включить сервис\n(Специальные возможности)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("4. Отключить ограничение батареи") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun addButton(title: String, onClick: () -> Unit) {
        root.addView(Button(this).apply {
            text = title
            isAllCaps = false
            setOnClickListener { onClick() }
        })
    }

    private fun openNotificationSettings() {
        startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        )
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun refreshStatus() {
        if (isServiceEnabled()) {
            status.text = "Сервис: ВКЛЮЧЁН"
            status.setTextColor(Color.rgb(0, 150, 0))
        } else {
            status.text = "Сервис: ВЫКЛЮЧЕН"
            status.setTextColor(Color.RED)
        }
    }
}
