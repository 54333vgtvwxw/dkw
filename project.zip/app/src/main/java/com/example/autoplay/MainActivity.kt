package com.example.autoplay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private lateinit var wordsBox: LinearLayout
    private lateinit var minField: EditText
    private lateinit var secField: EditText
    private lateinit var dirSpinner: Spinner
    private lateinit var leftF: EditText
    private lateinit var topF: EditText
    private lateinit var rightF: EditText
    private lateinit var bottomF: EditText
    private lateinit var tapAllBox: Switch

    // палитра (светлая / тёмная тема по настройкам телефона)
    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private var cField = 0
    private val cAccent = 0xFF6C5CE7.toInt()

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { save() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        cBg = if (dark) 0xFF121214.toInt() else 0xFFF2F3F7.toInt()
        cCard = if (dark) 0xFF1E1E24.toInt() else 0xFFFFFFFF.toInt()
        cText = if (dark) 0xFFEEEEF2.toInt() else 0xFF1B1B1F.toInt()
        cSub = if (dark) 0xFF9A9AA6.toInt() else 0xFF6B6B76.toInt()
        cField = if (dark) 0xFF2B2B34.toInt() else 0xFFEDEDF3.toInt()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(32))
        }

        // ---- Шапка ----
        root.addView(TextView(this).apply {
            text = "Fortnite AutoPlay"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
        })
        root.addView(TextView(this).apply {
            text = "Автоматически нажимает кнопки после матча"
            textSize = 14f
            setTextColor(cSub)
            setPadding(0, dp(2), 0, dp(14))
        })
        status = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        root.addView(status, LinearLayout.LayoutParams(WRAP, WRAP))

        // ---- Слова ----
        card("Слова для поиска", "Чем выше слово, тем оно важнее. Только латиница (Fortnite на английском).") {
            wordsBox = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            addView(wordsBox)
            Prefs.words(this@MainActivity).forEach { addRow(it) }
            addView(button("+  Добавить слово", false) {
                addRow("")
                (wordsBox.getChildAt(wordsBox.childCount - 1) as LinearLayout)
                    .getChildAt(0).requestFocus()
            }, lp(10))
        }

        // ---- Интервал ----
        card("Как часто проверять экран") {
            val total = Prefs.intervalSec(this@MainActivity)
            minField = numberField((total / 60).toString())
            secField = numberField((total % 60).toString())
            addView(inline(minField, labelText("  мин      "), secField, labelText("  сек")), lp(10))
            addView(sub("Чем реже проверка, тем меньше нагрев телефона. Для экрана итогов хватает 5–10 сек."))
        }

        // ---- Выбор кнопки ----
        card("Выбор нужной кнопки", "Что делать, если на экране несколько совпадений.") {
            dirSpinner = Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(
                    this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                    listOf(
                        "По порядку списка слов",
                        "Сверху вниз (самое верхнее)",
                        "Снизу вверх (самое нижнее)",
                        "Слева направо (самое левое)",
                        "Справа налево (самое правое)"
                    )
                )
                setSelection(Prefs.direction(this@MainActivity))
                background = rounded(cField, 10)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            addView(dirSpinner, lp(10))

            tapAllBox = Switch(this@MainActivity).apply {
                text = "Нажимать на все найденные"
                setTextColor(cText)
                isChecked = Prefs.tapAll(this@MainActivity)
                setPadding(0, dp(14), 0, dp(4))
            }
            addView(tapAllBox)

            addView(TextView(this@MainActivity).apply {
                text = "Область поиска, % экрана"
                setTextColor(cText)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(14), 0, dp(4))
            })
            val reg = Prefs.region(this@MainActivity)
            leftF = numberField(reg[0].toString())
            topF = numberField(reg[1].toString())
            rightF = numberField(reg[2].toString())
            bottomF = numberField(reg[3].toString())
            addView(inline(labelText("Слева  "), leftF, labelText(" %      Сверху  "), topF, labelText(" %")), lp(6))
            addView(inline(labelText("Справа  "), rightF, labelText(" %      Снизу  "), bottomF, labelText(" %")), lp(8))
            addView(sub("0 / 0 / 100 / 100 = весь экран. Только правая половина: слева 50, справа 100."))
        }

        // ---- Разрешения ----
        card("Настройка разрешений", "Пройдите шаги по порядку.") {
            addView(button("1.  Разрешить уведомления", false) {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                } else {
                    openNotificationSettings()
                }
            }, lp(10))
            addView(button("1б.  Настройки уведомлений приложения", false) {
                openNotificationSettings()
            }, lp(8))
            addView(button("2.  Сведения о приложении\n(⋮ → Разрешить ограниченные настройки)", false) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }, lp(8))
            addView(button("3.  Включить сервис\n(Специальные возможности)", true) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, lp(8))
            addView(button("4.  Отключить ограничение батареи", false) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }, lp(8))
        }

        root.addView(TextView(this).apply {
            text = "Epic Games может блокировать аккаунты за автоматизацию. Используйте на свой риск."
            textSize = 12f
            setTextColor(cSub)
            setPadding(dp(4), dp(16), dp(4), 0)
        })

        // слушатели ставим после создания всех полей
        minField.addTextChangedListener(watcher)
        secField.addTextChangedListener(watcher)
        for (f in listOf(leftF, topF, rightF, bottomF)) f.addTextChangedListener(watcher)
        tapAllBox.setOnCheckedChangeListener { _, _ -> save() }
        dirSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { save() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            addView(root)
        })
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    // ---------- оформление ----------

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun lp(topDp: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(topDp) }

    private fun card(title: String, hint: String? = null, build: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cCard, 16)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(cText)
        })
        if (hint != null) c.addView(sub(hint))
        c.build()
        root.addView(c, lp(12))
    }

    private fun sub(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(cSub)
        setPadding(0, dp(4), 0, 0)
    }

    private fun labelText(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(cText)
    }

    private fun inline(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        views.forEach { addView(it) }
    }

    private fun styleField(e: EditText) {
        e.setTextColor(cText)
        e.setHintTextColor(cSub)
        e.background = rounded(cField, 10)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun numberField(value: String) = EditText(this).apply {
        setText(value)
        inputType = InputType.TYPE_CLASS_NUMBER
        gravity = Gravity.CENTER
        minWidth = dp(70)
        styleField(this)
    }

    private fun button(title: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        textSize = 15f
        setTextColor(if (filled) Color.WHITE else cAccent)
        background = if (filled) rounded(cAccent, 12) else rounded(Color.TRANSPARENT, 12, cAccent)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    // ---------- строки со словами ----------

    private fun addRow(value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val field = EditText(this).apply {
            setText(value)
            hint = "Слово или фраза"
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            styleField(this)
        }
        field.addTextChangedListener(watcher)
        row.addView(field, LinearLayout.LayoutParams(0, WRAP, 1f))

        val trash = TextView(this).apply {
            text = "✕"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(cSub)
            setOnClickListener {
                wordsBox.removeView(row)
                save()
            }
        }
        row.addView(trash, LinearLayout.LayoutParams(dp(48), dp(48)))
        wordsBox.addView(row, lp(8))
    }

    // ---------- сохранение и статус ----------

    private fun save() {
        if (!::wordsBox.isInitialized || !::minField.isInitialized || !::secField.isInitialized ||
            !::dirSpinner.isInitialized || !::leftF.isInitialized || !::topF.isInitialized ||
            !::rightF.isInitialized || !::bottomF.isInitialized || !::tapAllBox.isInitialized
        ) return

        val list = (0 until wordsBox.childCount).mapNotNull { i ->
            val row = wordsBox.getChildAt(i) as LinearLayout
            (row.getChildAt(0) as EditText).text.toString().trim().ifEmpty { null }
        }
        Prefs.saveWords(this, list)

        val m = minField.text.toString().toIntOrNull() ?: 0
        val s = secField.text.toString().toIntOrNull() ?: 0
        Prefs.saveInterval(this, (m * 60 + s).coerceAtLeast(1))

        Prefs.saveDirection(this, dirSpinner.selectedItemPosition)
        Prefs.saveTapAll(this, tapAllBox.isChecked)
        fun pct(f: EditText, d: Int) = (f.text.toString().toIntOrNull() ?: d).coerceIn(0, 100)
        Prefs.saveRegion(this, pct(leftF, 0), pct(topF, 0), pct(rightF, 100), pct(bottomF, 100))
    }

    private fun openNotificationSettings() {
        startActivity(
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        )
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun refreshStatus() {
        val on = isServiceEnabled()
        status.text = if (on) "●  Сервис включён" else "●  Сервис выключен"
        status.background = rounded(if (on) 0xFF2E9E5B.toInt() else 0xFFD64545.toInt(), 20)
    }
}
