package com.example.autoplay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import java.util.concurrent.Executors
import kotlin.math.abs

class OcrLine(val text: String, val box: Rect)
class Hit(val box: Rect, val idx: Int, val text: String)

class AutoPlayService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private var tess: TessBaseAPI? = null

    private val cyrillic = Regex("[\\u0400-\\u04FF]")
    private val cooldownMs = 6000L   // пауза после нажатия
    private var lastTap = 0L
    private var busy = false
    private var busySince = 0L
    private var overlay: TextView? = null

    // плавающие кнопки и замок
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var lockBtn: TextView? = null
    private var pauseBtn: TextView? = null
    private var paused = false
    private var lockedPkg: String? = null
    private var currentPkg: String? = null
    private var lastReturn = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "panel") handler.post { applyPanelVisibility() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun norm(s: String) = s.trim().replace(Regex("\\s+"), " ")

    // строки с учётом языка, выбранного в приложении
    private fun s(id: Int, vararg args: Any): String =
        LocaleHelper.wrap(applicationContext).getString(id, *args)

    // ---------- плашка со статусом (без уведомлений и Toast) ----------

    private fun initOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                setBackgroundColor(0xCC000000.toInt())
                textSize = 13f
                setPadding(16, 8, 16, 8)
                maxLines = 4
                maxWidth = (resources.displayMetrics.widthPixels * 0.7).toInt()
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(tv, lp)
            overlay = tv
        } catch (e: Exception) {
            // без плашки сервис всё равно работает
        }
    }

    private fun say(msg: String) {
        handler.post { overlay?.text = msg }
    }

    // ---------- плавающие кнопки ----------

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun initPanel() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val size = dp(40)

            fun makeButton(symbol: String, onClick: () -> Unit) = TextView(this).apply {
                text = symbol
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = circle(0xAA000000.toInt())
                layoutParams = LinearLayout.LayoutParams(size, size).apply { bottomMargin = dp(6) }
                setOnTouchListener(dragListener(onClick))
            }

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val lock = makeButton("🔓") { toggleLock() }
            val pause = makeButton("⏸") { togglePause() }
            val gear = makeButton("⚙") {
                try {
                    startActivity(
                        Intent(this, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) { }
            }
            col.addView(lock)
            col.addView(pause)
            col.addView(gear)
            lockBtn = lock
            pauseBtn = pause

            val dm = resources.displayMetrics
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            val sx = Prefs.panelX(this)
            val sy = Prefs.panelY(this)
            lp.x = (if (sx >= 0) sx else dm.widthPixels - dp(56)).coerceIn(0, dm.widthPixels - dp(40))
            lp.y = (if (sy >= 0) sy else dp(120)).coerceIn(0, dm.heightPixels - dp(140))
            wm.addView(col, lp)
            panel = col
            panelParams = lp
            updateButtons()
            applyPanelVisibility()
        } catch (e: Exception) {
            // без панели сервис всё равно работает
        }
    }

    /** Нажатие = действие кнопки, перетаскивание = перемещение всей панели. */
    private fun dragListener(onClick: () -> Unit): View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return View.OnTouchListener { _, e ->
            val lp = panelParams
            val p = panel
            if (lp == null || p == null) return@OnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(p, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) Prefs.savePanelPos(this, lp.x, lp.y) else onClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun applyPanelVisibility() {
        val show = Prefs.showPanel(applicationContext)
        panel?.visibility = if (show) View.VISIBLE else View.GONE
        if (!show && lockedPkg != null) {
            // без кнопок снять замок было бы нечем
            lockedPkg = null
            updateButtons()
        }
    }

    private fun updateButtons() {
        val locked = lockedPkg != null
        lockBtn?.text = if (locked) "🔒" else "🔓"
        lockBtn?.background = circle(if (locked) 0xDDD64545.toInt() else 0xAA000000.toInt())
        pauseBtn?.text = if (paused) "▶" else "⏸"
        pauseBtn?.background = circle(if (paused) 0xDDE6A23C.toInt() else 0xAA000000.toInt())
    }

    private fun togglePause() {
        paused = !paused
        updateButtons()
        say(s(if (paused) R.string.ov_paused else R.string.ov_resumed))
    }

    // ---------- замок на приложении ----------

    private fun isIme(pkg: String): Boolean = try {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.any { it.packageName == pkg }
    } catch (e: Exception) {
        false
    }

    // системные окна, шторка, клавиатура и наше приложение замок не трогает
    private fun isAllowed(pkg: String) =
        pkg == packageName || pkg == "com.android.systemui" || pkg == "android" || isIme(pkg)

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun toggleLock() {
        if (lockedPkg != null) {
            lockedPkg = null
            updateButtons()
            say(s(R.string.ov_lock_off))
            return
        }
        val pkg = currentPkg ?: rootInActiveWindow?.packageName?.toString()
        if (pkg == null || isAllowed(pkg)) {
            say(s(R.string.ov_lock_fail))
            return
        }
        lockedPkg = pkg
        updateButtons()
        say(s(R.string.ov_lock_on, appLabel(pkg)))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (isAllowed(pkg)) return
        val locked = lockedPkg
        if (locked == null || pkg == locked) {
            currentPkg = pkg
            return
        }
        returnToLocked(locked)
    }

    private fun returnToLocked(pkg: String) {
        val now = System.currentTimeMillis()
        if (now - lastReturn < 800) return
        lastReturn = now
        say(s(R.string.ov_lock_pulled))
        try {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                startActivity(intent)
            }
        } catch (e: Exception) { }
        // запасной вариант: если игра не вернулась, нажимаем «Назад»
        handler.postDelayed({
            val front = rootInActiveWindow?.packageName?.toString()
            if (lockedPkg != null && front != null && front != lockedPkg && !isAllowed(front)) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }, 900)
    }

    // ---------- основной цикл ----------

    private val loop = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (busy && now - busySince > 20000) busy = false
            if (!paused && !busy && now - lastTap > cooldownMs) capture()
            handler.postDelayed(this, Prefs.intervalSec(applicationContext) * 1000L)
        }
    }

    override fun onServiceConnected() {
        initOverlay()
        initPanel()
        Prefs.sp(applicationContext).registerOnSharedPreferenceChangeListener(prefListener)
        say(s(R.string.ov_started))
        handler.post(loop)
    }

    private fun capture() {
        busy = true
        busySince = System.currentTimeMillis()
        // прячем плашку, чтобы она не попала на скриншот и не распозналась как кнопка
        overlay?.visibility = View.INVISIBLE
        handler.postDelayed({ shoot() }, 150)
    }

    private fun shoot() {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        overlay?.visibility = View.VISIBLE
                        try {
                            val hw = result.hardwareBuffer
                            val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hw.close()
                            if (bmp == null) {
                                busy = false
                                return
                            }
                            recognize(bmp)
                        } catch (e: Exception) {
                            say(s(R.string.ov_error, e.message ?: ""))
                            busy = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        overlay?.visibility = View.VISIBLE
                        say(s(R.string.ov_shot_failed, errorCode))
                        busy = false
                    }
                })
        } catch (e: Exception) {
            overlay?.visibility = View.VISIBLE
            say(s(R.string.ov_error, e.message ?: ""))
            busy = false
        }
    }

    // ---------- распознавание ----------

    private fun recognize(bmp: Bitmap) {
        val ctx = applicationContext
        val all = Prefs.words(ctx) + Prefs.exactWords(ctx)
        if (all.isEmpty()) {
            say(s(R.string.ov_no_words))
            busy = false
            return
        }
        val needCyr = all.any { cyrillic.containsMatchIn(it) }
        if (needCyr && !LangData.ready(ctx)) {
            say(s(R.string.ov_cyr_missing))
            busy = false
            return
        }

        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val lines = text.textBlocks.flatMap { it.lines }.mapNotNull { l ->
                    l.boundingBox?.let { b -> OcrLine(l.text, b) }
                }
                if (needCyr) {
                    // кириллицу читает Tesseract (медленнее), в отдельном потоке
                    ocrExecutor.execute {
                        val extra = try {
                            tessLines(bmp)
                        } catch (e: Throwable) {
                            emptyList()
                        }
                        handler.post {
                            handle(bmp.width, bmp.height, lines + extra)
                            busy = false
                        }
                    }
                } else {
                    handle(bmp.width, bmp.height, lines)
                    busy = false
                }
            }
            .addOnFailureListener {
                say(s(R.string.ov_error, it.message ?: "OCR"))
                busy = false
            }
    }

    private fun tessApi(): TessBaseAPI? {
        tess?.let { return it }
        val ctx = applicationContext
        if (!LangData.ready(ctx)) return null
        val api = TessBaseAPI()
        if (!api.init(LangData.baseDir(ctx).absolutePath, "rus+eng")) {
            api.recycle()
            return null
        }
        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
        tess = api
        return api
    }

    private fun tessLines(bmp: Bitmap): List<OcrLine> {
        val api = tessApi() ?: return emptyList()
        api.setImage(bmp)
        api.getUTF8Text() // запускает распознавание
        val iter = api.getResultIterator() ?: return emptyList()
        val out = ArrayList<OcrLine>()
        iter.begin()
        do {
            val t = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)
            val r = iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)
            if (t != null && r != null) out.add(OcrLine(t, r))
        } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE))
        iter.delete()
        return out
    }

    // ---------- выбор и нажатие ----------

    private fun handle(w: Int, h: Int, lines: List<OcrLine>) {
        val ctx = applicationContext
        val words = Prefs.words(ctx)
        val exact = Prefs.exactWords(ctx).map { norm(it) }

        // Слово ищется как целое: PLAY не сработает на PLAYER
        val patterns = words.map {
            Regex(
                "(?<![\\p{L}\\p{N}])" + Regex.escape(norm(it)) + "(?![\\p{L}\\p{N}])",
                RegexOption.IGNORE_CASE
            )
        }

        // область поиска в процентах экрана
        val reg = Prefs.region(ctx)
        var rl = reg[0] * w / 100
        var rt = reg[1] * h / 100
        var rr = reg[2] * w / 100
        var rb = reg[3] * h / 100
        if (rr <= rl || rb <= rt) { rl = 0; rt = 0; rr = w; rb = h }

        val hits = ArrayList<Hit>()
        val outside = ArrayList<String>()
        for (line in lines) {
            val t = norm(line.text)
            if (t.isEmpty()) continue
            var idx = patterns.indexOfFirst { it.containsMatchIn(t) }
            if (idx < 0) {
                val e = exact.indexOfFirst { it.equals(t, ignoreCase = true) }
                if (e >= 0) idx = words.size + e
            }
            if (idx < 0) continue
            val b = line.box
            if (b.centerX() in rl..rr && b.centerY() in rt..rb) {
                hits.add(Hit(b, idx, t))
            } else {
                outside.add(t)
            }
        }

        if (hits.isEmpty()) {
            if (outside.isNotEmpty()) {
                say(s(R.string.ov_seen, quoted(outside)) + "\n" + s(R.string.ov_outside))
            } else {
                val sample = lines.joinToString(" | ") { it.text }.take(80)
                say(s(R.string.ov_nomatch, if (sample.isEmpty()) s(R.string.ov_notext) else sample))
            }
            return
        }

        val ordered = when (Prefs.direction(ctx)) {
            1 -> hits.sortedBy { it.box.centerY() }
            2 -> hits.sortedByDescending { it.box.centerY() }
            3 -> hits.sortedBy { it.box.centerX() }
            4 -> hits.sortedByDescending { it.box.centerX() }
            else -> hits.sortedBy { it.idx }
        }
        // убираем дубли (одно слово могли прочитать оба распознавателя)
        val unique = ArrayList<Hit>()
        for (hit in ordered) {
            val dup = unique.any {
                abs(it.box.centerX() - hit.box.centerX()) < 60 &&
                    abs(it.box.centerY() - hit.box.centerY()) < 60
            }
            if (!dup) unique.add(hit)
        }
        val targets = if (Prefs.tapAll(ctx)) unique else unique.take(1)

        say(
            s(R.string.ov_seen, quoted(unique.map { it.text })) + "\n" +
                s(R.string.ov_tapping, quoted(targets.map { it.text }))
        )
        targets.forEachIndexed { i, hit ->
            handler.postDelayed(
                { tap(hit.box.centerX().toFloat(), hit.box.centerY().toFloat()) },
                i * 600L
            )
        }
    }

    private fun quoted(list: List<String>) =
        list.joinToString(", ") { "«$it»" }.take(100)

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        lastTap = System.currentTimeMillis()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            Prefs.sp(applicationContext).unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (e: Exception) { }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { overlay?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) { }
        ocrExecutor.execute { tess?.recycle(); tess = null }
        ocrExecutor.shutdown()
        super.onDestroy()
    }
}
