package com.example.autoplay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class AutoPlayService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    // Тексты кнопок (Fortnite должен быть на английском языке!)
    private val targets = listOf("PLAY AGAIN")

    private val intervalMs = 2000L   // как часто делать скриншот
    private val cooldownMs = 6000L   // пауза после нажатия
    private var lastTap = 0L
    private var busy = false

    private val loop = object : Runnable {
        override fun run() {
            if (!busy && System.currentTimeMillis() - lastTap > cooldownMs) capture()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        handler.post(loop)
    }

    private fun capture() {
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hw = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    if (bmp == null) { busy = false; return }
                    recognize(bmp)
                }
                override fun onFailure(errorCode: Int) { busy = false }
            })
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                for (block in text.textBlocks) for (line in block.lines) {
                    val t = line.text.uppercase().trim()
                    val box = line.boundingBox ?: continue
                    if (targets.any { t.contains(it) }) {
                        tap(box.centerX().toFloat(), box.centerY().toFloat())
                        return@addOnSuccessListener
                    }
                }
            }
            .addOnCompleteListener { busy = false }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        lastTap = System.currentTimeMillis()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
