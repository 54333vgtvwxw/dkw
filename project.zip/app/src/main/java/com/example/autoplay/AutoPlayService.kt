package com.example.autoplay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class Hit(val box: Rect, val idx: Int)

class AutoPlayService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val cooldownMs = 6000L   // пауза после нажатия
    private var lastTap = 0L
    private var busy = false
    private var busySince = 0L
    private var toast: Toast? = null
    private var overlay: TextView? = null

    private fun norm(s: String) = s.trim().replace(Regex("\\s+"), " ")

    private fun initOverlay() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE)
                setBackgroundColor(0xCC000000.toInt())
                textSize = 13f
                setPadding(16, 8, 16, 8)
                maxLines = 3
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(tv, lp)
            overlay = tv
        } catch (e: Exception) {
            toast = Toast.makeText(applicationContext, "overlay: " + e.message, Toast.LENGTH_LONG)
            toast?.show()
        }
    }

    private fun say(msg: String) {
        handler.post {
            overlay?.text = msg
            toast?.cancel()
            toast = Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT)
            toast?.show()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (busy && now - busySince > 8000) busy = false
            if (!busy && now - lastTap > cooldownMs) capture()
            // интервал берётся из настроек приложения каждый раз заново
            handler.postDelayed(this, Prefs.intervalSec(applicationContext) * 1000L)
        }
    }

    override fun onServiceConnected() {
        initOverlay()
        say("AutoPlay: сервис запущен")
        handler.post(loop)
    }

    private fun capture() {
        busy = true
        busySince = System.currentTimeMillis()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hw = result.hardwareBuffer
                            val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hw.close()
                            if (bmp == null) {
                                say("AutoPlay: bitmap = null")
                                busy = false
                                return
                            }
                            recognize(bmp)
                        } catch (e: Exception) {
                            say("AutoPlay: ошибка " + e.message)
                            busy = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        say("AutoPlay: скриншот не удался, код $errorCode")
                        busy = false
                    }
                })
        } catch (e: Exception) {
            say("AutoPlay: исключение " + e.message)
            busy = false
        }
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val ctx = applicationContext
                val words = Prefs.words(ctx)
                if (words.isEmpty()) {
                    say("AutoPlay: список слов пуст")
                    return@addOnSuccessListener
                }
                // Слово ищется как целое: PLAY не сработает на REPORT PLAYER
                val patterns = words.map {
                    Regex(
                        "(?<![\\p{L}\\p{N}])" + Regex.escape(norm(it)) + "(?![\\p{L}\\p{N}])",
                        RegexOption.IGNORE_CASE
                    )
                }
                // Область поиска (в процентах экрана)
                val reg = Prefs.region(ctx)
                var rl = reg[0] * bmp.width / 100
                var rt = reg[1] * bmp.height / 100
                var rr = reg[2] * bmp.width / 100
                var rb = reg[3] * bmp.height / 100
                if (rr <= rl || rb <= rt) { rl = 0; rt = 0; rr = bmp.width; rb = bmp.height }

                val all = text.textBlocks.flatMap { it.lines }
                val hits = ArrayList<Hit>()
                var outside = 0
                for (line in all) {
                    val t = norm(line.text)
                    val box = line.boundingBox ?: continue
                    val idx = patterns.indexOfFirst { it.containsMatchIn(t) }
                    if (idx < 0) continue
                    if (box.centerX() in rl..rr && box.centerY() in rt..rb) {
                        hits.add(Hit(box, idx))
                    } else {
                        outside++
                    }
                }

                if (hits.isEmpty()) {
                    if (outside > 0) {
                        say("AutoPlay: слово найдено, но вне заданной области")
                    } else {
                        val sample = all.joinToString(" | ") { it.text }.take(80)
                        say("AutoPlay видит: " + if (sample.isEmpty()) "(текста нет)" else sample)
                    }
                    return@addOnSuccessListener
                }

                val ordered = when (Prefs.direction(ctx)) {
                    1 -> hits.sortedBy { it.box.centerY() }
                    2 -> hits.sortedByDescending { it.box.centerY() }
                    3 -> hits.sortedBy { it.box.centerX() }
                    4 -> hits.sortedByDescending { it.box.centerX() }
                    else -> hits.sortedBy { it.idx }
                }
                val targets = if (Prefs.tapAll(ctx)) ordered else ordered.take(1)
                say("AutoPlay: найдено ${hits.size}, нажимаю ${targets.size}")
                targets.forEachIndexed { i, h ->
                    handler.postDelayed(
                        { tap(h.box.centerX().toFloat(), h.box.centerY().toFloat()) },
                        i * 600L
                    )
                }
            }
            .addOnFailureListener { say("AutoPlay: ошибка OCR " + it.message) }
            .addOnCompleteListener { busy = false }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        lastTap = System.currentTimeMillis()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
