package com.example.autoplay

import android.content.Context

object Prefs {
    private const val FILE = "autoplay"

    // Слова: ищутся как целые слова внутри текста
    val defaultWords = listOf("PLAY AGAIN", "CONTINUE")
    // Точные слова: на кнопке должно быть написано ровно это
    val defaultExact = listOf("PLAY")

    fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun readList(ctx: Context, key: String, default: List<String>): List<String> {
        val raw = sp(ctx).getString(key, null) ?: return default
        return raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun words(ctx: Context) = readList(ctx, "words", defaultWords)
    fun saveWords(ctx: Context, list: List<String>) {
        sp(ctx).edit().putString("words", list.joinToString("\n")).apply()
    }

    fun exactWords(ctx: Context) = readList(ctx, "exact", defaultExact)
    fun saveExactWords(ctx: Context, list: List<String>) {
        sp(ctx).edit().putString("exact", list.joinToString("\n")).apply()
    }

    fun intervalSec(ctx: Context): Int = sp(ctx).getInt("interval", 2).coerceAtLeast(1)
    fun saveInterval(ctx: Context, sec: Int) {
        sp(ctx).edit().putInt("interval", sec.coerceAtLeast(1)).apply()
    }

    // 0 = по порядку списков, 1 = сверху вниз, 2 = снизу вверх, 3 = слева направо, 4 = справа налево
    fun direction(ctx: Context): Int = sp(ctx).getInt("direction", 0)
    fun saveDirection(ctx: Context, v: Int) { sp(ctx).edit().putInt("direction", v).apply() }

    // область поиска в процентах экрана: слева, сверху, справа, снизу
    fun region(ctx: Context): IntArray {
        val p = sp(ctx)
        return intArrayOf(p.getInt("rl", 0), p.getInt("rt", 0), p.getInt("rr", 100), p.getInt("rb", 100))
    }
    fun saveRegion(ctx: Context, l: Int, t: Int, r: Int, b: Int) {
        sp(ctx).edit().putInt("rl", l).putInt("rt", t).putInt("rr", r).putInt("rb", b).apply()
    }

    fun tapAll(ctx: Context): Boolean = sp(ctx).getBoolean("tapall", false)
    fun saveTapAll(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("tapall", v).apply() }

    // язык интерфейса: "" = как в системе, "en", "ru"
    fun language(ctx: Context): String = sp(ctx).getString("lang", "") ?: ""
    fun saveLanguage(ctx: Context, v: String) { sp(ctx).edit().putString("lang", v).apply() }

    // плавающие кнопки поверх приложений
    fun showPanel(ctx: Context): Boolean = sp(ctx).getBoolean("panel", true)
    fun saveShowPanel(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("panel", v).apply() }
    fun panelX(ctx: Context): Int = sp(ctx).getInt("panel_x", -1)
    fun panelY(ctx: Context): Int = sp(ctx).getInt("panel_y", -1)
    fun savePanelPos(ctx: Context, x: Int, y: Int) {
        sp(ctx).edit().putInt("panel_x", x).putInt("panel_y", y).apply()
    }
}
