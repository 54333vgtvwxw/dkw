package com.example.autoplay

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {
    /** Возвращает контекст с языком, выбранным в приложении (или системным, если не выбран). */
    fun wrap(ctx: Context): Context {
        val lang = Prefs.language(ctx)
        if (lang.isEmpty()) return ctx
        val conf = Configuration(ctx.resources.configuration)
        conf.setLocale(Locale.forLanguageTag(lang))
        return ctx.createConfigurationContext(conf)
    }
}
